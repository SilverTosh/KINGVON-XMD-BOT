// KINGVON-XMD main bot code
console.log('KINGVON-XMD Bot Started');